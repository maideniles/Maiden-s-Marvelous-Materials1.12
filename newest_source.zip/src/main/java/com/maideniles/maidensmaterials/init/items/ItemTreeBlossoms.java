package com.maideniles.maidensmaterials.init.items;

import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.item.Item;

public class ItemTreeBlossoms extends ItemMaiden {

	public ItemTreeBlossoms(String name) {
		super(name);
	}

}
