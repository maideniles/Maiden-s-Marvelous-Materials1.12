package com.maideniles.maidensmaterials.init.items;

public class ItemPruningShears extends ItemMaiden {

	public ItemPruningShears(String name) {
		super(name);
		setMaxStackSize(1);
		setMaxDamage(48);
	}

}
