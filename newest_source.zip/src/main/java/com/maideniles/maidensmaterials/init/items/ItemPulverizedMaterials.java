package com.maideniles.maidensmaterials.init.items;

public class ItemPulverizedMaterials extends ItemMaiden {

	public ItemPulverizedMaterials(String name) {
		super(name);
		setMaxStackSize(16);
	}

}
