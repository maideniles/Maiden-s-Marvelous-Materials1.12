package com.maideniles.maidensmaterials.init.items;

public class CustomIngot extends ItemMaiden {
	public CustomIngot(String name) {
		super(name);
	}
}