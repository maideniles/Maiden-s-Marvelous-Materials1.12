package com.maideniles.maidensmaterials.init.items;

public class ItemGemBase extends ItemMaiden {
	public ItemGemBase(String name) {
		super(name);
	}
}