package com.maideniles.maidensmaterials;

import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.world.World;

public class Reference 
{
	public static final String MODID = "maidensmaterials";
	public static final String NAME = "MaidensMaterials";
	public static final String VERSION = "2.2";
	public static final String MCVRSION = "1.12.2";
	public static final String CLIENTPROXY = "com.maideniles.maidensmaterials.proxy.ClientProxy";
	public static final String COMMONPROXY = "com.maideniles.maidensmaterials.proxy.CommonProxy";
	
	
}